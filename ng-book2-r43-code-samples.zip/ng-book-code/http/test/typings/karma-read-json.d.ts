declare function readJSON(file: string): Object;
