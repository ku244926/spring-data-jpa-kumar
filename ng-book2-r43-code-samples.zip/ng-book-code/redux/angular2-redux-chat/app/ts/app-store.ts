import { OpaqueToken } from '@angular/core';

export const AppStore = new OpaqueToken('App.store');
