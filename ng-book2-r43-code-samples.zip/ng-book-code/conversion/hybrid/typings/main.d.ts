/// <reference path="main/ambient/angular-ui-router/index.d.ts" />
/// <reference path="main/ambient/angular/index.d.ts" />
/// <reference path="main/ambient/es6-shim/index.d.ts" />
/// <reference path="main/ambient/jquery/index.d.ts" />
/// <reference path="main/ambient/underscore/index.d.ts" />
